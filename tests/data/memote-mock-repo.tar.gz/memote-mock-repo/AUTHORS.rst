=======
Credits
=======

Model Maintainer
----------------

* `Christian Lieven <clie@biosustain.dtu.dk>`_

Contributors
------------

None yet. Why not be the first?
